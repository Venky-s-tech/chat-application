hi guys this is a chat applications build with firebase and react js with one on one chat feature,google sign-in authentication using firebase.
For set up:
1.npm install
2.npm firebase
3.set port = 3000 
npm start //for 1st port
4.set port = 3001
npm start // for 2nd port
